function getUserName() {
    var name = prompt("Qual é o seu nome?");
    return name;
}

document.getElementById("emailButton").addEventListener("click", function() {
    window.location.href = "mailto:seu-email@example.com?subject=Mensagem importante&body=Conteúdo da mensagem.";
});